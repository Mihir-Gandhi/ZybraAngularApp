﻿(function () {
    'use strict';
    angular
    .module('ZybraBankApp', ['ngResource','ui.bootstrap'])

})();